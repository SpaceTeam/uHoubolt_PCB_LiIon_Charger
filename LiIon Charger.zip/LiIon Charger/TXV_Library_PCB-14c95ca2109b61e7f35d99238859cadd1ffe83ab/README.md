# µHoubolt/Houbolt/TXV KiCad Library

## Usage
Add this repository to the KiCad project directory as a submodule
